self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "ac79ff8861d2ab328c4767426f1b4116",
    "url": "/minim/index.html"
  },
  {
    "revision": "622df7167931a882db9b",
    "url": "/minim/static/css/2.38d60fdd.chunk.css"
  },
  {
    "revision": "7bcd3a370d6c7524e2d1",
    "url": "/minim/static/css/main.d58ad4e1.chunk.css"
  },
  {
    "revision": "622df7167931a882db9b",
    "url": "/minim/static/js/2.7a120db9.chunk.js"
  },
  {
    "revision": "801eb6b718cfeb49e4699ab80a85e8cf",
    "url": "/minim/static/js/2.7a120db9.chunk.js.LICENSE"
  },
  {
    "revision": "7bcd3a370d6c7524e2d1",
    "url": "/minim/static/js/main.0279d7f1.chunk.js"
  },
  {
    "revision": "9c188536d15c27375c33",
    "url": "/minim/static/js/runtime-main.94c0212c.js"
  },
  {
    "revision": "36276bf672f94c08cc5a57966cb49641",
    "url": "/minim/static/media/Cardo-Italic.36276bf6.ttf"
  },
  {
    "revision": "9818302bde1c74eaa2f0331c0b0b1189",
    "url": "/minim/static/media/Cardo-Regular.9818302b.ttf"
  },
  {
    "revision": "a37b0c01c0baf1888ca812cc0508f6e2",
    "url": "/minim/static/media/MaterialIcons-Regular.a37b0c01.ttf"
  },
  {
    "revision": "0de987b3566b186fa6f4a2dadf7f322a",
    "url": "/minim/static/media/PlusJakartaSans-Medium.0de987b3.ttf"
  },
  {
    "revision": "eae9c18cee82a8a1a52e654911f8fe83",
    "url": "/minim/static/media/Product.eae9c18c.ttf"
  },
  {
    "revision": "a12e9e90ace26a31d886b21516f0a88f",
    "url": "/minim/static/media/renner-medium.a12e9e90.otf"
  }
]);